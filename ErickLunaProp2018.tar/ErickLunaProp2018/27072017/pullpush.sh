#!/bin/bash
git push origin master ;
git pull
