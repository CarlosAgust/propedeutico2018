#!/bin/bash
echo $1 ;
git add . ;
git commit -m "$1"
