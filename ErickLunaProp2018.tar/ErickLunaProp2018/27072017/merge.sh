#!/bin/bash
echo $1 ;
git merge $1
