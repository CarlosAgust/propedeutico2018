#!/bin/bash

touch $1
mkdir $2
echo "Written" > ./$1
cat ./$1
mv ./$1 ./$2/$3
echo "#!/bin/bash" > ./$2/$3
echo "git add ." >> ./$2/$3
echo "git commit" >> ./$2/$3
cat ./$2/$3
echo "Se creo el script"
