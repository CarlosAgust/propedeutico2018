#!/bin/bash

git pull -u origin https://github.com/RuySalgado/practica-27072017.git
git push -u origin https://github.com/RuySalgado/practica-27072017.git
