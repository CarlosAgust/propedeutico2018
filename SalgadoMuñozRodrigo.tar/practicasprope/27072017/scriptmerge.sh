#!/bin/bash

git merge $1
